package com.example.clothing_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
