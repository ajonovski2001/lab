import 'package:flutter/material.dart';


class Clothing {
  final String name;
  final String image;
  final String description;
  final double price;

  Clothing({
    required this.name,
    required this.image,
    required this.description,
    required this.price,
  });
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Clothing App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ClothingListScreen(),
    );
  }
}

class ClothingListScreen extends StatelessWidget {
  final List<Clothing> clothingItems = [
    Clothing(
      name: 'T-Shirt',
      image: 'assets/images/tshirt.png',
      description: 'A comfortable cotton t-shirt.',
      price: 19.99,
    ),
    Clothing(
      name: 'Jeans',
      image: 'assets/images/jeans.jpg',
      description: 'A pair of stylish blue jeans.',
      price: 49.99,
    ),
    Clothing(
      name: 'Jacket',
      image: 'assets/images/jacket.jpg',
      description: 'A warm winter jacket.',
      price: 79.99,
    ),
    Clothing(
      name: 'Sneakers',
      image: 'assets/images/sneakers.jpg',
      description: 'Comfortable running shoes.',
      price: 59.99,
    ),
    Clothing(
      name: 'Hoodie',
      image: 'assets/images/hoodie.jpg',
      description: 'A cozy hoodie for cool weather.',
      price: 39.99,
    ),
    Clothing(
      name: 'Sweater',
      image: 'assets/images/sweater.jfif',
      description: 'A soft wool sweater.',
      price: 69.99,
    ),
    Clothing(
      name: 'Shirt',
      image: 'assets/images/shirt.jpg',
      description: 'A classic button-up shirt.',
      price: 29.99,
    ),
    Clothing(
      name: 'Shorts',
      image: 'assets/images/shorts.jfif',
      description: 'A pair of comfortable shorts for summer.',
      price: 24.99,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('203223'),
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: clothingItems.length,
        itemBuilder: (context, index) {
          final item = clothingItems[index];
          return Card(
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ClothingDetailScreen(clothing: item),
                  ),
                );
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    item.image,
                    width: 500,
                    height: 500,
                    fit: BoxFit.cover,
                  ),
                  SizedBox(height: 10),
                  Text(
                    item.name,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text('\$${item.price.toStringAsFixed(2)}'),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class ClothingDetailScreen extends StatelessWidget {
  final Clothing clothing;

  ClothingDetailScreen({required this.clothing});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(clothing.name),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.asset(clothing.image, width: 200, height: 200),
            SizedBox(height: 20),
            Text(
              clothing.name,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              clothing.description,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            Text(
              '\$${clothing.price.toStringAsFixed(2)}',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

